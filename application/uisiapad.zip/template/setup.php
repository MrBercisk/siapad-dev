<?php 
/*======= preg_replace('/\r|\n|\t/','','') ==============*/
$theme 			   = [];
$theme['main'][]   = '';
require('topbar.php');
require('footer.php');


?>